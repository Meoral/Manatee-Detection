t_m = train_signal(1:800000);
v_m = train_signal(800000:length(train_signal));


% 
% 
% vset=zeros(510000,2);
% 
% vset(:,1) = z(1:510000);
% vset(:,2) = z(1:510000,2);
% 
% 
% figure;
% plot(1:510000,vset(1:510000),1:510000,vset(1:510000,2));
